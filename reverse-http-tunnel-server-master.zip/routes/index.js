var express = require('express');
var router = express.Router();
var { BrowserRequest } = rRequire('./services/BrowserRequest.js');
var { tunnel } = rRequire('./services/tunnel.js');

var bodyParser = require('body-parser');
var multer = require('multer');
var storage = multer.memoryStorage();
var upload = multer({ storage: storage });

// Middleware to handle POST request data
router.use(bodyParser.json());
router.use(bodyParser.urlencoded({ extended: true }));

router.post('/tunnel/handle-request', upload.single('data'), function(req, res, next) {
    var id = req.headers['x-request-id'];
    if (id) {
        let response = req.body;

        response.body = req.file ? req.file.buffer : req.body.data;

        if (!response.body) {
            response.body = req.body.error ? req.body.error :
                `Proxy responded to request ${id}, but file named "data" absent in POST data from proxy`;
            console.error('Tunnel responded with error:', response.body);
            response.status = 500;
        }

        tunnel.respondToBrowserRequest(id, response);
    } else {
        // If there's no x-request-id, we assume it's a new request from the browser and we need to proxy it
        new BrowserRequest(req, res);
    }
});

router.get('/*', function(req, res, next) {
    new BrowserRequest(req, res);
});

// Keep your testing route as is
router.post('/binary', upload.single('body'), function(req, res, next) {
    var fs = require('fs');
    fs.writeFile("./output.jpg", req.file.buffer, (err) => {
        console.log('RESULT', err);
        res.end();
    });
});

module.exports = router;
