const uuidv1 = require('uuid/v1');
const http = require('http');
const https = require('https');
var { tunnel } = require('./tunnel.js');

exports.BrowserRequest = class {
    constructor(req, res) {
        this.id = uuidv1();
        this.data = {
            id: this.id,
            method: req.method,
            url: req.url,
            headers: req.headers
        };
        this.responseToBrowser = res;

        // Forward the request to its destination
        this.forwardRequest(req);
    }

    forwardRequest(originalReq) {
        const requestOptions = {
            method: originalReq.method,
            headers: originalReq.headers
        };

        const protocol = originalReq.url.startsWith('https') ? https : http;

        const proxyReq = protocol.request(originalReq.url, requestOptions, (proxyRes) => {
            let body = [];
            proxyRes.on('data', (chunk) => body.push(chunk));
            proxyRes.on('end', () => {
                this.respond({
                    status: proxyRes.statusCode,
                    headers: JSON.stringify(proxyRes.headers),
                    body: Buffer.concat(body).toString()
                });
            });
        });

        proxyReq.on('error', (error) => {
            this.respond({
                status: 500,
                headers: JSON.stringify({ 'Content-Type': 'text/plain' }),
                body: 'Error occurred while making the request.'
            });
        });

        if (/POST|PUT/.test(originalReq.method) && originalReq.body) {
            proxyReq.write(originalReq.body);
        }
        proxyReq.end();
    }

    respond(data) {
        if (data.status == 200) {
            this.responseToBrowser.set(JSON.parse(data.headers));
            this.responseToBrowser.send(data.body);
        } else {
            this.responseToBrowser.status(parseInt(data.status));
            this.responseToBrowser.send(data.body.toString());
        }
    }
};
